# OhU_hud

Tf2 UI for optimized competitve play. Inspired by omp/oxide hud and uses an edit of ya_hud's mainmenu ui.

**Legacy: outdated and broken use at your own risk!**


# Important Stuff


![screenshot](https://i.imgur.com/jcUo5PA.jpg)
* **U+:** new health variant

![screenshot](https://i.imgur.com/Wrj9Qpk.jpg)
* **U:** old health variant

### Crosshairs
* To adjust crosshairs open scripts/hudlayout.res. 
* Find the crosshair you want and change the xpos and ypos untill you are satisfied.

### In order to change the scoreboards:
  * In the resources/ui folder change "scoreboardhighlander6s".res to "scoreboard".res and the default to "scorboardoriginal".

### What happened to the Uhud variant?

The U hud variant is now inside the new resources/ui directory, the file is labeled hudplayerhealthU.res. To use this change the file name to hudplayerhealth.res and change the original to a different name or delete it.
**currently optimized for 16:9 and 16:10**


